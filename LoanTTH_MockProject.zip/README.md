# SoleMate - Mock E-commerce Project
This repository is a **mock implementation** and deliverable set for the *SoleMate* e-commerce platform,
created according to the uploaded project brief (SoleMate 2.pdf). The mock contains documentation, a small backend and frontend skeleton,
database schema, API spec, CI config, and additional artifacts for demonstration and handoff.

**I have read and followed the uploaded requirements file** (SoleMate 2.pdf). See reference: file provided by user. fileciteturn0file0

## Contents
- `docs/` : SRS, architecture, RTM, project plan, testing plan, wireframes and ER diagram
- `backend/` : Express.js API skeleton, schema, Dockerfile, tests
- `frontend/` : Next.js minimal skeleton (pages and components)
- `.github/workflows/ci.yml` : GitHub Actions CI example (lint & tests)
- `docker-compose.yml` : local compose to run postgres + backend + frontend
- `postman_collection.json` : basic API collection
- `scripts/seed.sql` : sample data seeds
- `solemate-mock.zip` : archive of this project (this file)

## How to run (locally, approximate)
1. Ensure Docker & Docker Compose are installed.
2. From repository root: `docker-compose up --build`
3. Backend: http://localhost:4000
   Frontend: http://localhost:3000

> This is a mock skeleton intended for handoff and further development. See `docs/` for detailed requirements, design, and test plans.
