
const express = require('express');
const app = express();
const PORT = process.env.PORT || 4000;

app.use(express.json());

// Health
app.get('/api/health', (req, res) => res.json({status: 'ok'}));

// Simple product endpoints (mock data)
const products = [
  {id:1, name:'SoleMate Runner', price:79.99, sku:'SM-RUN-001'},
  {id:2, name:'SoleMate Classic', price:99.99, sku:'SM-CLS-002'}
];

app.get('/api/products', (req, res) => {
  const q = (req.query.q || '').toLowerCase();
  if(q) {
    return res.json(products.filter(p => p.name.toLowerCase().includes(q)));
  }
  res.json(products);
});

app.get('/api/products/:id', (req, res) => {
  const p = products.find(x => x.id === parseInt(req.params.id));
  if(!p) return res.status(404).json({error:'not found'});
  res.json(p);
});

// Mock checkout
app.post('/api/checkout', (req, res) => {
  // In real world integrate Stripe/PayPal. Here we accept mock payments.
  const {cart, payment} = req.body || {};
  if(!cart || cart.length===0) return res.status(400).json({error:'cart-empty'});
  // return fake order
  res.json({orderId: Math.floor(Math.random()*1000000), status:'paid'});
});

app.listen(PORT, ()=> console.log(`SoleMate API (mock) listening on ${PORT}`));
