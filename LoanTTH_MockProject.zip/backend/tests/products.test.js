
/**
 * Basic test example (mock)
 */
const request = require('supertest');
const appUrl = 'http://localhost:4000';

describe('Products API (mock)', ()=> {
  test('GET /api/products returns 200', async ()=> {
    const res = await request(appUrl).get('/api/products');
    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBeTruthy();
  });
});
