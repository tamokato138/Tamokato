
# API - SoleMate (Mock)
Base URL: /api

## Key endpoints (mock)
- GET /api/health
- GET /api/products
- GET /api/products/{id}
- POST /api/checkout

See `docs/openapi.yaml` for a minimal OpenAPI specification.
