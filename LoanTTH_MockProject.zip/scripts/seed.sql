
INSERT INTO products (sku,name,description,price,category) VALUES
('SM-RUN-001','SoleMate Runner','Lightweight running shoe',79.99,'running'),
('SM-CLS-002','SoleMate Classic','Everyday casual shoe',99.99,'casual');

INSERT INTO users (email,password_hash,full_name) VALUES
('alice@example.com','<hashed-password>','Alice Nguyen'),
('bob@example.com','<hashed-password>','Bob Tran');
