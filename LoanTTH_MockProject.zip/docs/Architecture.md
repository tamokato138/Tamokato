
# Architecture - High Level & Low Level Design (Mock)

## High-Level Components
- **Frontend**: Next.js (React) for server-side rendering & SEO, responsive UI, TailwindCSS for styling
- **Backend (API)**: Node.js + Express (RESTful), microservices candidate boundaries for product, order & payment services
- **Database**: PostgreSQL primary store; Redis for caching & session store
- **Storage**: S3-compatible object storage for product images
- **CDN**: CloudFront (or equivalent) for static assets
- **CI/CD**: GitHub Actions -> build -> test -> deploy (ECS/EC2/Amplify)

## Data Flow
1. Client requests product page -> CDN or Next.js SSR -> API call to Product Service -> Postgres
2. Checkout flow -> Payment gateway (Stripe) -> webhook -> order created/updated

## Technology Rationale
- Next.js: SEO-friendly, great for e-commerce landing pages and product pages
- Node.js/Express: Rapid development, large ecosystem for middleware & SDKs
- PostgreSQL: Relational model fits orders/inventory and complex queries
- Redis: Caching product listings, sessions to reduce DB load

## Diagrams (ER diagram included as `docs/er_diagram.png`)
