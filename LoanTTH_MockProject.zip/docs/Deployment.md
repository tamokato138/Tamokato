
# Deployment Checklist & Rollback (Mock)

## Deployment Steps (production)
1. Build backend & frontend images and push to registry
2. Apply DB migrations (ensure backups)
3. Deploy backend (rolling update) behind load balancer
4. Deploy frontend (CDN invalidation if necessary)
5. Run smoke tests

## Rollback Plan
- Keep previous image versions; if critical issue occurs, redeploy previous image & restore DB snapshot within maintenance window.

## Monitoring
- Use CloudWatch/Datadog for metrics and alerts
- SLOs: Page load <= 2s, error rate < 1%
