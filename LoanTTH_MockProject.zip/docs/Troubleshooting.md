
# Troubleshooting & FAQs (Mock)

Q: Backend returns 500 on /api/products
A: Check server logs, verify DB connectivity, and ensure migrations were applied.

Q: Payments failing in production
A: Verify payment gateway keys, webhook endpoints and check 3rd party console for errors.
