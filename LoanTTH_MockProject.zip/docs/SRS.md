
# Software Requirements Specification (SRS) - SoleMate (Mock)

## 1. Introduction
SoleMate is an online shoe retail store. The platform enables customers to browse products, manage carts, checkout using payment gateways, and track orders.
Admins can manage catalog, inventory and orders. This SRS captures the functional and non-functional requirements derived from the project brief.

## 2. Scope
This SRS applies to the SoleMate e-commerce web application (desktop + mobile responsive) and backend services.

## 3. Functional Requirements (high-level)
FR-001: User registration & authentication (email/password, social optional)
FR-002: Product catalog browsing with filtering & search
FR-003: Product detail page with images, sizes, reviews & ratings
FR-004: Shopping cart management (add/update/remove)
FR-005: Checkout flow and payment integration (Stripe mock)
FR-006: Order history & tracking for users
FR-007: Customer profile & address management
FR-008: Admin dashboard for product, order, and inventory management
FR-009: Inventory management and stock alerts
FR-010: Promotions (discount codes) and application rules
FR-011: Product reviews and rating moderation

## 4. Non-functional Requirements (NFR)
NFR-001: Performance - typical page load < 2s under baseline
NFR-002: Scalability - design to handle 50k concurrent users (horizontal scaling)
NFR-003: Security - PCI-DSS requirements for payment handling; use TLS; encrypt sensitive data at rest
NFR-004: Availability - target 99.9% uptime
NFR-005: Compatibility - responsive across modern desktop, tablet, and mobile browsers

## 5. Acceptance Criteria (examples)
- FR-001: Users can register and login; password complexity enforced; session cookies expire after 30 days.
- FR-004: Cart persists per user and between sessions.
- FR-005: Mock payment integration returns success/failure; orders created only on successful payment response.

## 6. Traceability & Testability
An RTM (requirements traceability matrix) maps each FR to test cases and acceptance criteria (see `docs/RTM.csv`).

## 7. Assumptions
- Payment provider will be integrated via standard SDKs (Stripe/PayPal).
- Shipping & tax calculations are simplified for mock deliverables.
