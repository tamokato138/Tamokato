
# Testing Plan (Mock)

## Test Types Included
- Unit tests (backend functions)
- Integration tests (API endpoints)
- End-to-end smoke tests (checkout flow)
- Security scans (static analysis suggestions)
- Performance testing (JMeter or k6 recommended)

## Example test cases
- TC-Auth-01: Register and login a user, validate session cookie created
- TC-Cat-01: Query /api/products?q=runner returns expected product
- TC-Checkout-01: Submit sample cart to /api/checkout and assert order status 'paid'
