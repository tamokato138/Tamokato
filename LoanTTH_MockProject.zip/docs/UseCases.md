
# Use Cases & User Stories

## Primary Actors
- Customer (guest or registered)
- Admin (catalog & order management)
- Warehouse staff (inventory updates)

## Key User Stories (format: As a <role>, I want <goal>, so that <benefit>)
1. As a Customer, I want to search and filter shoes by size, color and category so that I can find items quickly.
2. As a Customer, I want to add items to a cart and edit quantities so I can purchase multiple sizes.
3. As a Customer, I want to checkout using a secure payment method so I can complete my purchase.
4. As an Admin, I want to create/update product listings and inventory counts so the catalog is accurate.
5. As Warehouse Staff, I want to see low stock alerts so I can restock products in time.

## Use Case Diagram (textual)
- Customer -> Browse Catalog -> View Product -> Add to Cart -> Checkout -> View Order
- Admin -> Manage Products -> Update Inventory -> View Orders
