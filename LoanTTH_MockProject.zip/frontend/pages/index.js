
import React, {useEffect, useState} from 'react';

export default function Home() {
  const [products, setProducts] = useState([]);
  useEffect(()=>{
    fetch('/api/products')
      .then(r=>r.json())
      .then(setProducts)
      .catch(console.error);
  },[]);
  return (
    <div style={{fontFamily:'Arial, sans-serif', padding:20}}>
      <h1>SoleMate - Mock Store</h1>
      <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(240px, 1fr))', gap:20}}>
        {products.map(p => (
          <div key={p.id} style={{border:'1px solid #ddd', padding:12, borderRadius:6}}>
            <h3>{p.name}</h3>
            <p>Price: ${p.price}</p>
            <button>Add to cart</button>
          </div>
        ))}
      </div>
    </div>
  )
}
